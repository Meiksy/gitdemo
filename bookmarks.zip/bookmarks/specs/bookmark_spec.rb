require('minitest/autorun')
require('minitest/rg')
require_relative('../models/bookmark')

class TestBookmark <Minitest::Test

  def setup
    params = {
      'page_address' => 'youtube.com',          
      'description' => 'Youtube',
      'type' =>'video',
    }

    @bookmark = Bookmark.new(params)
  end

  def test_page_address
    assert_equal("youtube.com", @bookmark.page_address)
  end

  def test_description
    assert_equal("Youtube", @bookmark.description)
  end

  def test_type
    assert_equal("video", @bookmark.video)
  end

end