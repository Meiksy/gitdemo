
CREATE TABLE bookmarks (
page_address inet
desciption varchar(255)
);