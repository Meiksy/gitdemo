require('pg')
require( 'pry-byebug')

class Bookmark

attr_reader :page_address, :description, :reading, :video, :music, :id

  def initialize( params )
    @id = nil || params['id']
    @page_address = params['page_address']
    @description = params['description']
    @type = params['type']
  end

  def page_address
    return @page_address
  end

  def save 
    sql = "INSERT INTO bookmarks (page_address, description) VALUES (
          '#{@page_address}', '#{@description}','#{@reading}', '#{video}', '#{music}')"
    Bookmark.run_sql(sql)
  end

  def self.all()
    bookmarks = Bookmark.run_sql("SELECT * FROM bookmarks" )
    result = bookmarks.map { |bookmark| Bookmark.new(bookmark) }
    return result
  end

  def self.select(bookmark_id)
    bookmark = Bookmark.run_sql("SELECT * FROM bookmarks WHERE id = #{bookmark_id}")
    result = Bookmark.new(bookmark[0])
    return result
  end

  def self.update(params)
    sql = "UPDATE bookmarks SET 
          page_address = '#{params['page_address']}',  
          description = '#{params['description']}', type = '#{'type'}',
          WHERE id= '#{params['id']}'"
      Bookmark.run_sql(sql)
  end


  def self.destroy(id)
    Bookmark.run_sql("Delete FROM bookmarks WHERE id = #{id}")
  end

  private 

  def self.run_sql(sql)

    begin
      db = PG.connect({dbname: 'bookmarks', host: 'localhost'})
      result = db.exec(sql)
      return result
    ensure
      db.close
    end

  end


end