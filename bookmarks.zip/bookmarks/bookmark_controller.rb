require('sinatra')
require('sinatra/contrib/all') if development?
require_relative('./models/bookmark')

# NEW
get '/bookmark/new' do
  erb(:new)
end

# CREATE
post '/bookmark' do
  @bookmark = Bookmark.new(params)
  @bookmark.save
  erb(:create)
end

# INDEX
get '/bookmark' do
  @bookmark= Bookmark.all
  erb( :index )
end

# SHOW
get '/bookmark/:id' do
  @bookmark = Bookmark.select(params[:id])
  erb(:show)
end

# EDIT
get '/bookmark/:id/edit'  do
  @bookmark = Bookmark.select(params[:id])
  erb(:edit)
end

# UPDATE
post '/bookmark/:id' do
  @bookmark = Bookmark.update(params)
  redirect to ("/bookmark/#{params[:id]}")
end

post '/bookmark/:id/delete'  do
  Bookmark.destroy(params[:id])
  redirect to ("/bookmark")
end