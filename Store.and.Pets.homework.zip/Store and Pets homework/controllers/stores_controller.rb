require_relative('../models/store.rb')

get '/stores' do
  #INDEX
  @stores = Store.all()
  erb :"stores/index"
end

get '/stores/new' do
  #NEW
  erb :"stores/new"
end

post '/stores' do
  #CREATE
  @store = Store.new( params )
  @store.save()
  redirect '/stores'
end

get '/stores/:id' do
  #SHOW
  @store = Store.find(params[:id])
  @stores = @store.players()
  erb :"teams/show"
end

get '/stores/:id/edit' do
  #EDIT
  @store = Store.find(params[:id])
  erb :"stores/edit"
end

post '/stores/:id' do
  #UPDATE
  @store = Store.new( params )
  @store.update()
  redirect to("/stores/#{params['id']}")
end

delete '/stores/:id' do
  #DELETE
end
