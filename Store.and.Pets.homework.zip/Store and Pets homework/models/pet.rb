require('pg')

class Pet
  attr_reader :id, :store_id, :pet_name, :pet_type, :image
  @@db_credentials = { dbname: 'Petz', host: 'localhost' }


  def initialize(options) 
    @id = options["id"] or nil
    @store_id = options['store_id']
    @pet_name = options["pet_name"]
    @pet_type = options["pet_type"]
    @image = options['image']
  end

  def team()
    sql = "SELECT * FROM stores WHERE id = #{@store_id}"
    result = Pet.run_sql( sql )
    Store.new( result[0] )
  end

  def save()
    sql = "INSERT INTO pets ( 
      id,
      store_id,
      pet_name,
      pet_type,
      image) 
      VALUES (
      '#{ @pet_name }',
      '#{ @store_id }'
      )"
    Pet.run_sql( sql )
  end

  def self.find(id)
   sql = "SELECT * FROM pets WHERE id = #{id.to_i}"
   result = Pet.run_sql( sql )
   return Pet.new( result[0] )
  end

  def update()
    sql = "UPDATE pets SET pet_name='#{ @pet_name }', store_id = #{ @store_id } WHERE id = #{@id}"
    return Pet.run_sql( sql )
  end

  private

  def self.run_sql( sql )
    begin
      db = PG.connect( @@db_credentials )
      result = db.exec( sql )
    ensure
      db.close
    end
    return result
  end

end