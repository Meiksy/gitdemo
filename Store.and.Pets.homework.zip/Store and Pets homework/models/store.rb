require('pg')
require( 'pry-byebug' )

class Store 
  attr_reader :id, :store_name, :address, :stock_type 
  @@db_credentials = { dbname: 'Petz', host: 'localhost' }

  def initialize(options)
    @id = options["id"] or nil
    @store_name = options["store_name"]
    @address = options["address"]
    @stock_type = options["stock_type"] 
  end

  def pets()
    sql = "SELECT * FROM pets WHERE store_id=#{@id} ORDER BY store_name"
    pets = Store.run_sql(sql)
    result = pets.map { |pet| Pet.new(pet) } 
  end

  def self.all()
    sql = "SELECT * FROM teams ORDER BY store_name"
    stores = Store.run_sql( sql )
    result = stores.map { |store| Store.new(store) } 
  end

  def save()
    sql = "INSERT INTO stores ( 
      name, 
      manager) 
      VALUES (
      '#{ @store_name }',
      '#{ @address }',
      '#{ @stock_type }'
      )"

    return Store.run_sql( sql )
  end

  def self.find(id)
   sql = "SELECT * FROM stores WHERE id = #{id.to_i}"
   result = Store.run_sql( sql )
   team = Store.new( result[0] )
  end

  def update()
    sql = "UPDATE stores SET name='#{ @store_name }', address='#{ @address }', '#{stock_type}' WHERE id = #{@id}"
    return Store.run_sql( sql )
  end

  private 

  def self.run_sql( sql )
    begin
      db = PG.connect( @@db_credentials )
      result = db.exec( sql )
    ensure
      db.close
    end
    return result
  end

end
