CREATE TABLE stores (
  id serial4 primary key,
  store_name varchar(255),
  address varchar(255),
  stock_type varchar(255)
  -- Exotic/Domestic for stock_type.
);

CREATE TABLE pets (
  id serial4 primary key,
  store_id int4 references stores(id),
  pet_name varchar(255),
  pet_type varchar(255),
  image varchar(255)
);


