require( 'minitest/autorun' )
require( 'minitest/rg' )
require_relative( '../models/store' )
require_relative( '../models/pet' )

class TestPetz < MiniTest::Test


  def setup
    options = {
      "store_name" => 'Petz Store', 
      "address" => 'Edinburgh'
    }
    @store = Store.new( options )

  end


  # def test_max_players()
  #   # Ummm......
  #   assert_equal( true, Team.max_players?(1) )
  # end

end