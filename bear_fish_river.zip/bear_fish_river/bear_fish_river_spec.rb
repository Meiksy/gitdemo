require ('minitest/autorun')
require_relative('bear_fish_river')
require_relative('fish')


class TestBear < Minitest::Test

    def bears
      bear1 = bear.new("Yogi", "Grizzly", "Smarter than the average bear", [])
      bear2 = bear.new("Baloo", "Jungle", "Look for the bare necessities", [])
      bear3 = bear.new("Winnie", "Honey bear", "Honey!", [])
      bear4 = bear.new("Paddington", "London", "Please look after this bear", [])
    #The bears tummys are currently empty.

    bears = [ bear1, bear2, bear3 ]
    end

    def fish
      fish1 = "Nemo"
      fish2 = "Dora"
      fish3 = "Bill"
    end

    def river
      river = [ fish1, fish2, fish3 ]
    end


end

