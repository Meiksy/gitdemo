class Fish


  def initialize (fish)
    @fish = 
  end
# = fishes?

end