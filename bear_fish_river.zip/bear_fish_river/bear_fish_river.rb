class Bear

  def initialize (bears)
    @bears = bears
  end


end