## First star up sinatra in the terminal.
## http://localhost:4567/address

require( 'sinatra' )
require( 'sinatra/contrib/all' )

# require_relative( '' )

require( 'json' )

get "/address" do
    content_type( :json )

    @address = address{
        address: '3 ARGYLE HOUSE',
        building: 'CODEBASE',
        postcode: 'e13 zqf',
        phone: '0131558030'
    }

    # return result.to_json()
  end
