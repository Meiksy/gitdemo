require( 'minitest/autorun' )
require_relative( '' )

class TestSinatraHomework < Minitest::Test

  def test_postcode
    assert_equal("E13 ZQF", @postcode.uppcase)
  end

end